

import user.home.UserTabMenu;

public class MainRun {

	public MainRun() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		UserTabMenu start = new UserTabMenu();

	}

}
