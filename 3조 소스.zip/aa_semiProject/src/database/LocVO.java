package database;

public class LocVO {
	private int loc_code;
	private String loc1;
	private String loc2;

	public LocVO() {
	}

	public int getLoc_code() {
		return loc_code;
	}

	public void setLoc_code(int loc_code) {
		this.loc_code = loc_code;
	}

	public String getLoc1() {
		return loc1;
	}

	public void setLoc1(String loc1) {
		this.loc1 = loc1;
	}

	public String getLoc2() {
		return loc2;
	}

	public void setLoc2(String loc2) {
		this.loc2 = loc2;
	}


}
